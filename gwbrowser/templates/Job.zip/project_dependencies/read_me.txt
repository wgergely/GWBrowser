Plugins, applications, font files and any other software the project depends on should be placed in this folder.

Ideally a pointer to the application installers used in the project should be included too for backwards compatibility.