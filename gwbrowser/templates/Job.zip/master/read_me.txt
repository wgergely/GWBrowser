All final deliverables should be placed in this folder. If the project doesn't contain any deliverables any final
images should be placed in this folder, even if the project is only a pitch containing images. 

Think about this folder as the placeholder for the project's most important files - no matter what happens, the contents
of the ``master`` folder will be preserved in its entirety.