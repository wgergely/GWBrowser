This is the main work-folder for storing all project files including any 3D/2D assets, builds, sequences, shots, etc.
The `assets` folder is generally used for things shared between multiple shots, eg. character rigs, or builds, whilst
`shots` would be sequential shots.

Different stages of production can co-exist in the same container folder. Eg. animation and layout shots can be placed
in the shots folder if they're prefixed with a stage abbreviation:

ANI_SH010
ANI_SH020
ANI_SH030
LAY_SH010
LAY_SH020
LAY_SH030
..

The contents of the ``assets`` and ``shots`` folder will largely depend on the project at hand. Some projects don't require
complex setups.