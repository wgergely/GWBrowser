Common is the placeholder for any incoming material from clients, agencies, general references,
audio edits and 
so forth.



This is intentionally a vague container as the contents of this folder will depend largely on
the project 
itself.
