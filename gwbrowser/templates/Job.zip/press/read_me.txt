This is the place to put any behind the scenes (BTS) materials and any online material ready to share.

Ideally, in the case of moving image projects the online h264/h265 mix-downs should be placed in this folder as well.

