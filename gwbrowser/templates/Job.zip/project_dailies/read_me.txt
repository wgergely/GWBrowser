Any material that needs to be sent, or show internally should be placed in this folder.
Usually this folder should contain a list of folders with a timestamp. Eg.:

20190530/
20190531/
20190601/
..

This folders usually will contain the package to be presented to the client or reviewed internally.